public class Week6 {
    public static void main(String[] args) {
        
        String[] categories = {"Fiction", "Nepali"};
        String[] titles = new String[2];
        double[] prices = new double[2];
        
        titles[0] = "Ashamati - 5";
        prices[0] = 750.0;
        
        titles[1] = "Muna Madan";
        prices[1] = 450.0;
        
        for (int i = 0; i < 2; i++) {
            System.out.println(categories[i] + " : " + titles[i] + " - Rs. " + 
                               String.format("%.2f", prices[i]));
        }
    }
}
