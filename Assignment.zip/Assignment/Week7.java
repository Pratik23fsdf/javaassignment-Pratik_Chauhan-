public class Week7 {
    public static void main(String[] args) {
        
        BankAccount acc1 = new BankAccount("ACC001", "Hari Sharma", 5000.0);
        BankAccount acc2 = new BankAccount("ACC002", "Sita Thapa", 12000.0);
        
        acc1.deposit(3000.0);
        acc1.withdraw(1500.0);
        
        acc2.deposit(5000.0);
        acc2.withdraw(2000.0);
        
        acc1.displayBalance();
        acc2.displayBalance();
    }
}
