public class BankAccount {
    
    private String accountNumber;
    private String holderName;
    private double balance;
    
    public BankAccount(String accountNumber, String holderName, double balance) {
        this.accountNumber = accountNumber;
        this.holderName = holderName;
        this.balance = balance;
    }
    
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited: Rs. " + amount);
        }
    }
    
    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawn: Rs. " + amount);
        } else {
            System.out.println("Insufficient balance or invalid amount");
        }
    }
    
    public void displayBalance() {
        System.out.println("Account: " + accountNumber + 
                           " | Holder: " + holderName + 
                           " | Balance: Rs. " + balance);
    }
    
    public double getBalance() {
        return balance;
    }
}
