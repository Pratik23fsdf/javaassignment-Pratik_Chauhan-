public class Week5 {
    public static void main(String[] args) {
        
        for (int rate = 8; rate <= 12; rate++) {
            
            double principal = 1000.0;
            
            while (principal <= 50000) {
                
                double maturityAmount = principal * Math.pow(1 + (rate / 100.0) / 12, 60);
                double fee = maturityAmount * 0.005;
                double finalAmount = maturityAmount - fee;
                
                System.out.println(principal + " " + rate + " " + maturityAmount + " " + fee + " " + finalAmount);
                
                principal += 5000;
            }
        }
    }
}
