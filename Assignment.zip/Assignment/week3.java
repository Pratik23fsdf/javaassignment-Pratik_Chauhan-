import java.util.Scanner;

public class week3 {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter distance in km: ");
        double km = sc.nextDouble();
        
        System.out.print("Enter time in minutes: ");
        int minutes = sc.nextInt();
        
        double fare = km * 20;                    
        
        fare = (minutes >= 1320 || minutes < 300) ? fare * 1.25 : fare;
        
        System.out.printf("Total Fare: Rs. %.2f%n", fare);
        
        sc.close();
    }
}
